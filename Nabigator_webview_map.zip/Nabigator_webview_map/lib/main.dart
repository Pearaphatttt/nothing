import 'package:flutter/material.dart';
import 'home.dart';
import 'page1.dart';
import 'page2.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Test',
      home: const MyHompage(),
    );
  }
}

class MyHompage extends StatefulWidget {
  const MyHompage({super.key});
  @override
  State<MyHompage> createState() => _MyHompageState();
}

class _MyHompageState extends State<MyHompage> {
  int _currentIndex = 0;
  final tabs = [
    Home(),
    Page1(),
    Page2(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: tabs[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.shifting,
        iconSize: 40,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
            backgroundColor: Colors.cyan
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pages),
            label: 'Page1',
            backgroundColor: const Color.fromARGB(255, 43, 30, 30)
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pages_outlined),
            label: 'Page2',
            backgroundColor: const Color.fromARGB(255, 0, 212, 46)
          ),
        ],
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }
}