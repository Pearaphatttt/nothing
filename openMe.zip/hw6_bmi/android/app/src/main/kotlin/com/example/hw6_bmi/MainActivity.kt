package com.example.hw6_bmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
