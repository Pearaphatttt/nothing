import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Page1 extends StatefulWidget {
  const Page1({super.key});

  @override
  State<Page1> createState() => _Page1State();
}

class _Page1State extends State<Page1> {
  late final WebViewController _controller;
  @override
  void initState() {
    super.initState();
    _controller = 
        WebViewController()..setJavaScriptMode(
          JavaScriptMode.unrestricted,
        )..loadRequest(Uri.parse('https://www.cokeshopth.com/'));
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('WebView Cocacora'),
      ),
      body: WebViewWidget(controller: _controller),
    );
  }
}