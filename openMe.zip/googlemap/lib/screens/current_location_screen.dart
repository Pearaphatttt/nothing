import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CurrentLocation extends StatefulWidget {
  const CurrentLocation({Key? key}) : super(key: key);

  @override
  State<CurrentLocation> createState() => _CurrentLocationState();
}

class _CurrentLocationState extends State<CurrentLocation> {
  late GoogleMapController googleMapController;

  static const CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(14.0708, 101.4269), // ตั้งค่ากลางระหว่างจุดทั้งหมด
    zoom: 15.0,
  );

  Set<Marker> markers = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Current Location"),
      ),
      body: GoogleMap(
        markers: markers,
        mapType: MapType.normal,
        initialCameraPosition: _initialCameraPosition,
        onMapCreated: (GoogleMapController controller) {
          googleMapController = controller;
        },
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            onPressed: () async {
              Position position = await _determinePosition();
              googleMapController.animateCamera(CameraUpdate.newCameraPosition(
                CameraPosition(
                  target: LatLng(position.latitude, position.longitude),
                  zoom: 16.0,
                ),
              ));

              markers.clear();
              markers.add(Marker(
                markerId: const MarkerId("Current_Location"),
                position: LatLng(position.latitude, position.longitude),
                infoWindow: const InfoWindow(title: "ตำแหน่งปัจจุบัน"),
              ));
              setState(() {});
            },
            label: const Text("Current Location"),
            icon: const Icon(Icons.location_history),
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            onPressed: _showMarkers,
            label: const Text("Show 3 Markers"),
            icon: const Icon(Icons.place),
          ),
        ],
      ),
    );
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error("Location Service Disabled");
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error("Location Permission Denied");
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error("Location Permission is permanently denied.");
    }

    return await Geolocator.getCurrentPosition();
  }

  void _showMarkers() {
    markers.clear();
    markers.addAll([
      Marker(
        markerId: const MarkerId("Male_Dormitory"),
        position: const LatLng(14.0726, 101.4246),
        infoWindow: const InfoWindow(title: "หอพักชาย"),
      ),
      Marker(
        markerId: const MarkerId("Digital_Agriculture_Faculty"),
        position: const LatLng(14.0708, 101.4269),
        infoWindow: const InfoWindow(title: "คณะอุตสาหกรรมเกษตรดิจิทัล"),
      ),
      Marker(
        markerId: const MarkerId("KMUTNB_Airport"),
        position: const LatLng(14.0695, 101.4297),
        infoWindow: const InfoWindow(title: "สนามบิน มจพ.ปราจีนบุรี"),
      ),
    ]);

    googleMapController.animateCamera(CameraUpdate.newLatLngBounds(
      LatLngBounds(
        southwest: const LatLng(14.0680, 101.4230),
        northeast: const LatLng(14.0735, 101.4305),
      ),
      80,
    ));

    setState(() {});
  }
}
