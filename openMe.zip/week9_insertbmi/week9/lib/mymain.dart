import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

main() {
  runApp(const ShowInf());
}

class ShowInf extends StatefulWidget {
  const ShowInf({super.key});

  @override
  State<ShowInf> createState() => _ShowInfState();
}

class _ShowInfState extends State<ShowInf> {
  List list = [];

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  @override
  void initState() {
    super.initState();
    listData();
  }

  Future<String> listData() async {
    var response = await http.get(
      Uri.http('26.229.24.141:9898', 'emp'),
      headers: {"Accept": "application/json"},
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    setState(() {
      list = jsonDecode(response.body);
    });
    return "Success";
  }

  String _calculateBMI(double weight, double height) {

    double bmi = weight / ((height / 100) * (height / 100));
    String bmiValue = bmi.toStringAsFixed(2); 

    if (bmi < 18.5) {
      return "$bmiValue (Underweight)";
    } else if (bmi >= 18.5 && bmi < 25) {
      return "$bmiValue (Normal)";
    } else if (bmi >= 25 && bmi < 30) {
      return "$bmiValue (Overweight)";
    } else {
      return "$bmiValue (Obesity)";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('DB Test (with BMI)'),
      ),
      body: Center(
        child: ListView.builder(
          itemCount: list.length,
          itemBuilder: (BuildContext context, int index) {
            return Card(
              child: ListTile(
                leading: Text(list[index]["id"].toString()),
                title: Row(
                  children: [
                    Expanded(child: Text(list[index]["name"])),
                    Expanded(child: Text(list[index]["email"])),
                  ],
                ),
                subtitle: (list[index]["weight"] != null && list[index]["height"] != null)
                    ? Text("BMI: ${_calculateBMI(
                         double.parse(list[index]["weight"].toString()),
                         double.parse(list[index]["height"].toString()),
                       )}")
                    : Text("BMI: - "),
                trailing: Wrap(
                  spacing: 5,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.green),
                      onPressed: () {
                        Map data = {
                          'id': list[index]['id'],
                          'name': list[index]['name'],
                          'weight': list[index]['weight'],
                          'height': list[index]['height'],
                          'email': list[index]['email'],
                          'phone': list[index]['phone'],
                          'address': list[index]['address'],
                        };
                        _showedit(data);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () => _showDel(list[index]["id"]),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          _addNewDialog();
        },
      ),
    );
  }

  Future<void> _addNewDialog() async {
    _nameController.clear();
    _weightController.clear();
    _heightController.clear();
    _emailController.clear();
    _phoneController.clear();
    _addressController.clear();

    return showDialog<void>(
      context: context,
      barrierDismissible: false, 
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('AlertDialog Title'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp name",
                    labelText: "Name",
                  ),
                ),
                TextField(
                  controller: _weightController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    hintText: "Enter weight (kg)",
                    labelText: "Weight",
                  ),
                ),
                TextField(
                  controller: _heightController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    hintText: "Enter height (cm)",
                    labelText: "Height",
                  ),
                ),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Email",
                    labelText: "Email",
                  ),
                ),
                TextField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp phone",
                    labelText: "Phone",
                  ),
                ),
                TextField(
                  controller: _addressController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Address",
                    labelText: "Address",
                  ),
                ),
                const SizedBox(height: 20),
                const Text('กรอกข้อมูลให้เรียบร้อยแล้วกด ยืนยัน'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('ยืนยัน'),
              onPressed: () {
                add_data();
                Navigator.of(context).pop();
              },
            )
          ],
        );
      },
    );
  }

  void add_data() async {
    double w = double.tryParse(_weightController.text) ?? 0;
    double h = double.tryParse(_heightController.text) ?? 0;

    Map data = {
      'name': _nameController.text,
      'weight': w,
      'height': h,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
    };

    var body = jsonEncode(data);
    var response = await http.post(
      Uri.http('26.229.24.141:9898', 'create'),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: body,
    );

    print('Response status (ADD): ${response.statusCode}');
    print('Response body (ADD): ${response.body}');
    listData(); // refresh list
  }

  Future<void> _showDel(int id) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // ต้องกดปุ่มเท่านั้น
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('ลบข้อมูล $id'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[
                Text('ยืนยันการลบข้อมูล กด ยืนยัน'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('ยืนยัน'),
              onPressed: () {
                del_data(id);
                Navigator.of(context).pop();
              },
            )
          ],
        );
      },
    );
  }

  void del_data(int id) async {
    var response = await http.delete(
      Uri.http('26.229.24.141:9898', 'delete/$id'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        "Accept": "application/json"
      },
    );
    print('Response status (DEL): ${response.statusCode}');
    print('Response body (DEL): ${response.body}');
    listData(); // refresh list
  }

  Future<void> _showedit(Map data) async {
    // ใส่ค่าลงใน Controller
    _nameController.text = data['name'] ?? '';
    _weightController.text = (data['weight'] ?? '').toString();
    _heightController.text = (data['height'] ?? '').toString();
    _emailController.text = data['email'] ?? '';
    _phoneController.text = data['phone'] ?? '';
    _addressController.text = data['address'] ?? '';

    return showDialog<void>(
      context: context,
      barrierDismissible: false, // ต้องกดปุ่มเท่านั้น
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('ทดสอบการ Edit'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp name", 
                    labelText: "Name"
                  ),
                ),
                TextField(
                  controller: _weightController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    hintText: "Enter weight (kg)",
                    labelText: "Weight",
                  ),
                ),
                TextField(
                  controller: _heightController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    hintText: "Enter height (cm)",
                    labelText: "Height",
                  ),
                ),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Email", 
                    labelText: "Email"
                  ),
                ),
                TextField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp phone", 
                    labelText: "Phone"
                  ),
                ),
                TextField(
                  controller: _addressController,
                  decoration: const InputDecoration(
                    hintText: "Enter emp Address", 
                    labelText: "Address"
                  ),
                ),
                const Text('ปรับปรุงข้อมูลให้เรียบร้อยแล้วกด ยืนยัน'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('ยืนยัน'),
              onPressed: () {
                edit_data(data['id']);
                Navigator.of(context).pop();
              },
            )
          ],
        );
      },
    );
  }

  void edit_data(id) async {
    double w = double.tryParse(_weightController.text) ?? 0;
    double h = double.tryParse(_heightController.text) ?? 0;

    Map updatedData = {
      'name': _nameController.text,
      'weight': w,
      'height': h,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
    };

    var body = jsonEncode(updatedData);
    var response = await http.put(
      Uri.http('26.229.24.141:9898', 'update/$id'),
      headers: <String, String>{
        "Content-Type": "application/json; charset=UTF-8",
        "Accept": "application/json"
      },
      body: body,
    );

    print('Response status (EDIT): ${response.statusCode}');
    print('Response body (EDIT): ${response.body}');
    listData(); // refresh list
  }
}
