import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class GradesPage extends StatefulWidget {
  const GradesPage({super.key});

  @override
  State<GradesPage> createState() => _GradesPageState();
}

class _GradesPageState extends State<GradesPage> {
  final CollectionReference subjectsCollection =
      FirebaseFirestore.instance.collection('subjects');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("APP Grade GPA"),
        backgroundColor: const Color.fromARGB(255, 86, 255, 128),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: subjectsCollection.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text('Something went wrong'));
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

    
          int totalCredit = 0;
          double totalScore = 0.0;

          for (var doc in docs) {
            final data = doc.data() as Map<String, dynamic>;

            final credit = (data['credit'] as int?) ?? 0;
            final grade = (data['grade'] as int?) ?? 0;

            totalCredit += credit;
            totalScore += credit * grade;
          }

          double gpa = 0.0;
          if (totalCredit > 0) {
            gpa = totalScore / totalCredit;
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Card(
                  child: ListTile(
                    title: const Text("Summary"),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Num of Subject: ${docs.length}"),
                        Text("Total Credit: $totalCredit"),
                        Text("GPA Score: ${gpa.toStringAsFixed(2)}"),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final data = doc.data() as Map<String, dynamic>;

                    final subjectName = data['subjectName'] ?? '-';
                    final credit = data['credit'] ?? 0;
                    final grade = data['grade'] ?? 0;
                    return Card(
                      child: ListTile(
                        title: Text("Subject: $subjectName"),
                        subtitle: Text("Credit: $credit | Grade: $grade"),
                        trailing: SizedBox(
                          width: 100,
                          child: Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () => editSubjectDialog(doc.id, data),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () => deleteSubject(doc.id),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color.fromARGB(255, 86, 255, 128),
        onPressed: () => addSubjectDialog(),
        child: const Icon(Icons.add),
      ),
    );
  }

  void addSubjectDialog() {
    String subjectName = "";
    int? selectedCredit;
    int? selectedGrade;

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Insert Data"),
          content: StatefulBuilder(
            builder: (context, setStateDialog) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration:
                          const InputDecoration(labelText: "Subject Name"),
                      onChanged: (value) {
                        subjectName = value;
                      },
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text("Credit: "),
                        const SizedBox(width: 10),
                        DropdownButton<int>(
                          hint: const Text("Select"),
                          value: selectedCredit,
                          items: const [
                            DropdownMenuItem(value: 1, child: Text("1")),
                            DropdownMenuItem(value: 2, child: Text("2")),
                            DropdownMenuItem(value: 3, child: Text("3")),
                          ],
                          onChanged: (value) {
                            setStateDialog(() {
                              selectedCredit = value;
                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text("Grade: "),
                        const SizedBox(width: 10),
                        DropdownButton<int>(
                          hint: const Text("Select"),
                          value: selectedGrade,
                          items: const [
                            DropdownMenuItem(value: 0, child: Text("0")),
                            DropdownMenuItem(value: 1, child: Text("1")),
                            DropdownMenuItem(value: 2, child: Text("2")),
                            DropdownMenuItem(value: 3, child: Text("3")),
                            DropdownMenuItem(value: 4, child: Text("4")),
                          ],
                          onChanged: (value) {
                            setStateDialog(() {
                              selectedGrade = value;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {
                if (subjectName.isNotEmpty &&
                    selectedCredit != null &&
                    selectedGrade != null) {
                  await subjectsCollection.add({
                    'subjectName': subjectName,
                    'credit': selectedCredit,
                    'grade': selectedGrade,
                  });
                }
                if (!mounted) return;
                Navigator.pop(context);
              },
              child: const Text("Add"),
            ),
          ],
        );
      },
    );
  }


  void editSubjectDialog(String docId, Map<String, dynamic> currentData) {

    String subjectName = currentData['subjectName'] ?? '';
    int? selectedCredit = currentData['credit'] ?? 0;
    int? selectedGrade = currentData['grade'] ?? 0;

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Edit Data"),
          content: StatefulBuilder(
            builder: (context, setStateDialog) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration:
                          const InputDecoration(labelText: "Subject Name"),
                      controller: TextEditingController(text: subjectName),
                      onChanged: (value) {
                        subjectName = value;
                      },
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text("Credit: "),
                        const SizedBox(width: 10),
                        DropdownButton<int>(
                          value: selectedCredit,
                          items: const [
                            DropdownMenuItem(value: 1, child: Text("1")),
                            DropdownMenuItem(value: 2, child: Text("2")),
                            DropdownMenuItem(value: 3, child: Text("3")),
                          ],
                          onChanged: (value) {
                            setStateDialog(() {
                              selectedCredit = value;
                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text("Grade: "),
                        const SizedBox(width: 10),
                        DropdownButton<int>(
                          value: selectedGrade,
                          items: const [
                            DropdownMenuItem(value: 0, child: Text("0")),
                            DropdownMenuItem(value: 1, child: Text("1")),
                            DropdownMenuItem(value: 2, child: Text("2")),
                            DropdownMenuItem(value: 3, child: Text("3")),
                            DropdownMenuItem(value: 4, child: Text("4")),
                          ],
                          onChanged: (value) {
                            setStateDialog(() {
                              selectedGrade = value;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {

                await subjectsCollection.doc(docId).update({
                  'subjectName': subjectName,
                  'credit': selectedCredit,
                  'grade': selectedGrade,
                });
                if (!mounted) return;
                Navigator.pop(context);
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }


  void deleteSubject(String docId) async {
    await subjectsCollection.doc(docId).delete();
  }
}
